package practica.m3uf4;

/**
 *
 * 301015
 * @author mor
 */
public interface AnimalOps {
    
    public void menjar(Aliment a);
    
    public void reproduirse();
    
}
